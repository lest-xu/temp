<?php
/**
 * Threads Icons
 * 
 * PHP Version 5
 * 
 * @category MyBB_18
 * @package  Threads_Icons
 * @author   chack1172 <NBerardozzi@gmail.com>
 * @license  https://creativecommons.org/licenses/by-nc/4.0/ CC BY-NC 4.0
 * @link     http://www.chack1172.altervista.org/Projects/MyBB-18/Threads-Icons.html
 */

$l['ticon_custom'] = "上传帖子主题图片:";
$l['postdata_invalid_ticon_type'] = "不合理的图片格式. 图片必须是 GIF, JPEG, BMP or PNG 格式.";
$l['postdata_uploadfailed_ticon'] = "图片上传失败. 请选择正常的图片格式再重新上传.";
$l['ticon_noedit'] = "保存图片";
$l['ticon_remove'] = "移除图片";
$l['ticon_edit'] = "或者上传一个新的图片";