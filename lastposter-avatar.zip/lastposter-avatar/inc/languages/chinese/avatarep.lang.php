<?php
/**
*  Language English
*  Last Poster Avatar 3.0
*
*  
*  Autor: Lester
*/
$l['avatarep_user_profile'] = "查看资料";
$l['avatarep_user_messages'] = "查看信息";
$l['avatarep_user_sendpm'] = "发送 PM";
$l['avatarep_user_sendemail'] = "发送 E-mail";
$l['avatarep_user_threads'] = "查看帖子";
$l['avatarep_user_error'] = " 错误 ";
$l['avatarep_user_error_text'] = " 你需要登录材料查看内容 ";
$l['avatarep_user_alt'] = "{1}的头像";
$l['avatarep_user_no_avatar'] = "没有头像";
$l['avatarep_retrieving'] = "获取数据";
$l['avatarep_loading'] = "加载中...";