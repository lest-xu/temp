<?php
/***************************************************************************
 *
 *   NewPoints plugin (/inc/languages/newpoints.lang.php)
 *   
 *   Website: http://www.mybb-plugins.com
 *
 *   NewPoints plugin for MyBB - A complex but efficient points system for MyBB.
 *
 ***************************************************************************/
 
/****************************************************************************
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
****************************************************************************/

$l['newpoints'] = "积分系统";
$l['newpoints_home'] = '主页';
$l['newpoints_menu'] = '菜单';
$l['newpoints_donate'] = '捐赠';
$l['newpoints_donated'] = '你成功的捐赠 {1} 分给这个用户.';
$l['newpoints_user'] = '用户';
$l['newpoints_user_desc'] = '输入你想要捐赠的用户名.';
$l['newpoints_amount'] = '数量';
$l['newpoints_amount_desc'] = '输入捐赠分数的数量.';
$l['newpoints_reason'] = '原因';
$l['newpoints_reason_desc'] = '(可选) 输入捐赠的原因.';
$l['newpoints_submit'] = '提交';
$l['newpoints_donate_subject'] = '新的捐赠';
$l['newpoints_donate_message'] = '你好, 我刚刚捐赠给你 {1} 顺德币.';
$l['newpoints_donate_message_reason'] = '你好, 我刚刚捐赠给你 {1} 顺德币. 原因:[quote]{2}[/quote]';
$l['newpoints_donations_disabled'] = '捐赠系统被管理员禁用.';
$l['newpoints_cant_donate_self'] = '你不可给自己捐赠.';
$l['newpoints_invalid_amount'] = '你输入了不合理的顺德币数量.';
$l['newpoints_invalid_user'] = '你输入了一个不合理的用户名.';
$l['newpoints_donate_log'] = '{1}-{2}-{3}';
$l['newpoints_stats_disabled'] = '统计被系统管理员禁用.';
$l['newpoints_statistics'] = '统计';
$l['newpoints_richest_users'] = '土豪用户';
$l['newpoints_last_donations'] = '最后捐赠';
$l['newpoints_from'] = '从';
$l['newpoints_to'] = '去';
$l['newpoints_noresults'] = '没有结果.';
$l['newpoints_date'] = '日期';
$l['newpoints_not_enough_points'] = '你没有足够的顺德币. 需要: {1}';
$l['newpoints_task_ran'] = '备份积分';
$l['newpoints_amount_paid'] = '获得的数量';
$l['newpoints_source'] = '来源';
$l['newpoints_home_desc'] = '论坛全新的积分系统-【顺德币】上线啦.<br />你可以有很多方式来使用顺德币.<br /><br /><strong>如何获得顺德币?</strong><br /><table align="center"><tr><td align="left"><strong>来源</strong></td><td align="right"><strong>获得的数量</strong></td></tr>{1}</table><br />';
$l['newpoints_home_credits'] = '<br />如果你有任何的问题请联系论坛管理员.';
$l['newpoints_action'] = '操作';
$l['newpoints_chars'] = '字符';
$l['newpoints_max_donations_control'] = '在过去的15分钟你已获得到最大的上限顺德币 {1}. 请休息一下再发布.';

// Settings translation
$l['newpoints_setting_newpoints_income_newpost_title'] = '新的回复';
$l['newpoints_setting_newpoints_income_newpost_desc'] = '从新回复获得的顺德币.';
$l['newpoints_setting_newpoints_income_newthread_title'] = '新帖子';
$l['newpoints_setting_newpoints_income_newthread_desc'] = '从新帖子获得的顺德币.';
$l['newpoints_setting_newpoints_income_newpoll_title'] = '新的投票';
$l['newpoints_setting_newpoints_income_newpoll_desc'] = '从新的投票获得的顺德币.';
$l['newpoints_setting_newpoints_income_perchar_title'] = '每个字符';
$l['newpoints_setting_newpoints_income_perchar_desc'] = '从新的字符获得的顺德币.';
$l['newpoints_setting_newpoints_income_minchar_title'] = '最少字符';
$l['newpoints_setting_newpoints_income_minchar_desc'] = '达到最少字符才能获得顺德币.';
$l['newpoints_setting_newpoints_income_newreg_title'] = '新用户注册';
$l['newpoints_setting_newpoints_income_newreg_desc'] = '从推荐新用户获得的顺德币.';
$l['newpoints_setting_newpoints_income_pervote_title'] = '每个投票';
$l['newpoints_setting_newpoints_income_pervote_desc'] = '从每个用户投票获得的顺德币.';
$l['newpoints_setting_newpoints_income_perreply_title'] = '每个回复';
$l['newpoints_setting_newpoints_income_perreply_desc'] = '从每个回复获得的顺德币.';
$l['newpoints_setting_newpoints_income_pmsent_title'] = '每个发送的PM(私密消息)';
$l['newpoints_setting_newpoints_income_pmsent_desc'] = '从每个发送的私密消息获得的顺德币.';
$l['newpoints_setting_newpoints_income_perrate_title'] = '每个评分';
$l['newpoints_setting_newpoints_income_perrate_desc'] = '从每个评分获得的顺德币.';
$l['newpoints_setting_newpoints_income_pageview_title'] = '每张页面浏览';
$l['newpoints_setting_newpoints_income_pageview_desc'] = '从用户每张页面浏览获得的顺德币.';
$l['newpoints_setting_newpoints_income_visit_title'] = '每个访问';
$l['newpoints_setting_newpoints_income_visit_desc'] = '从每个用户访问论坛获得的顺德币. ("访问" = 访问论坛15分钟)';
$l['newpoints_setting_newpoints_income_referral_title'] = '每个推荐';
$l['newpoints_setting_newpoints_income_referral_desc'] = '从每个推荐的用户获得的顺德币.';


?>