<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['error_no_connection'] = '创建邮件服务器连接失败: ';
$l['error_no_message'] = '未指定邮件内容.';
$l['error_no_subject'] = '未指定邮件标题.';
$l['error_no_recipient'] = '未指定收件人.';
$l['error_not_sent'] = '通过 php 的 mail 函数发送邮件失败.';
$l['error_status_missmatch'] = '服务器返回结果异常, 返回中: ';
$l['error_data_not_sent'] = '邮件无法发送到服务器: ';

$l['error_occurred'] = '执行过程中出现下列错误, 请修正错误后再试.<br />';
