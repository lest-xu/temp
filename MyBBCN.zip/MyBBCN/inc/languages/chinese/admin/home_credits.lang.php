<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['mybb_credits'] = "MyBB名人堂";
$l['mybb_credits_description'] = "这些人贡献了他们的时间和努力，用以创造MyBB。";
$l['about_the_team'] = "关于团队";
$l['check_for_updates'] = "检查更新";
$l['error_communication'] = "下载最新的名人堂失败，请稍候再试";
$l['no_credits'] = "没有已保存的MbBB名人堂。<a href=\"index.php?module=home-credits&amp;fetch_new=1\">点击以更新</a>。";

