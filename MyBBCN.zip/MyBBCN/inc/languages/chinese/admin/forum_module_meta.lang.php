<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['forums_and_posts'] = "版面 &amp; 帖子";

$l['forum_management'] = "论坛管理";
$l['forum_announcements'] = "版面公告";
$l['moderation_queue'] = "审核队列";
$l['attachments'] = "附件";

$l['can_manage_forums'] = "可以管理论坛？";
$l['can_manage_forum_announcements'] = "可以管理公告？";
$l['can_moderate'] = "可以处理回帖、主题、附件？";
$l['can_manage_attachments'] = "可以管理附件？";

