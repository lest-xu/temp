<?php
/* by Tomasz 'Devilshakerz' Mlynski [devilshakerz.com]; Copyright (C) 2014-2016
 released under Creative Commons BY-NC-SA 4.0 license: https://creativecommons.org/licenses/by-nc-sa/4.0/ */

// server
$l['dvz_sb_shoutbox'] = '在线聊天';
$l['dvz_sb_archive'] = '在线聊天历史';
$l['dvz_sb_archivelink'] = '历史';
$l['dvz_sb_last_read_link'] = '跳转到最后一次的对话';
$l['dvz_sb_last_read_unmark_all'] = '标记所有对话';
$l['dvz_sb_default'] = '输入你的内容...';
$l['dvz_sb_user_blocked'] = '你已经被禁止使用在线聊天功能.';
$l['dvz_sb_minposts'] = '输入至少 {MINPOSTS} 内容才能使用在线聊天功能.';
$l['dvz_sb_mod'] = '在线聊天管理';
$l['dvz_sb_mod_banlist'] = '禁止的用户名的名单';
$l['dvz_sb_mod_banlist_button'] = '保存';
$l['dvz_sb_mod_clear'] = '删除历史对话...';
$l['dvz_sb_mod_clear_all'] = '所有信息';
$l['dvz_sb_mod_clear_button'] = '删除';
$l['dvz_sb_activity'] = '查看 <a href="%s">在线聊天的历史</a>';

// JavaScript
$l['dvz_sb_delete_confirm'] = '你确定要删除这个信息吗?';
$l['dvz_sb_antiflood'] = '请等待至少 {ANTIFLOOD} 秒才能发生新的信息.';
$l['dvz_sb_permissions'] = '抱歉！你没有这个权限.';
